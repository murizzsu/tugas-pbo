<?php include('uas.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>RNTBooks | Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="dist/img/books.png" alt="AdminLTELogo" height="60" width="60">
  </div>

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
     
    </ul>

   
  </nav>
  <!-- /.navbar -->


  
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="dist/img/books.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">RNTBooks</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
     

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          


          <li class="nav-header"><strong>DASHBOARD</strong></li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book-open"></i>
              <p>RNTBooks</p>
            </a>
          </li>
          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <?php
include('koneksi.php');
    $query = mysqli_query($koneksi,"SELECT * FROM perpustakaan ORDER BY id DESC");
    
    ?>
    
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="card">
          <div class="card-header">
            <a href="" class="btn btn-info float-right" data-toggle="modal" data-target="#tambah"><i class="fas fa-plus"></i> Tambah</a>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th style="width: 10px">#</th>
                  <th>Peminjam</th>
                  <th>Nama Buku</th>
                  <th>Kategori</th>
                  <th>Penerbit</th>
                  <th class="text-center">Aksi</th>
                </tr>
              </thead>
              <tbody>
              <?php if(mysqli_num_rows($query)>0){ ?>
                  <?php
                      $no = 1;
                      while($data = mysqli_fetch_array($query)){
                  ?>
                <tr> 
                  <td><?php echo $no ?></td>
                  <td><?php echo $data['nama_peminjam'] ?></td>
                  <td><?php echo $data['nama_buku'] ?></td>
                  <td><?php echo $data['kategori'] ?></td>
                  <td><?php echo $data['penerbit'] ?></td>
                  

                  <td>
                    <div class="d-flex justify-content-center">
                      <button type="button" class="btn bg-info " data-toggle="modal" data-target="#info<?=$no?>"><i class="fas fa-info-circle"></i></button>
                      <button type="button" class="btn bg-warning mx-2" data-toggle="modal" data-target="#edit<?=$data['id']?>"><i class="fas fa-edit"></i></button>
                      <a href= "hapus.php?id=<?php echo $data['id']; ?>" onclick="return confirm('Kamu Yakin Hapus Ini?')" class="btn bg-danger"><i class="far fa-trash-alt"></i></a>
                    </div>
                  </td>
                </tr>
                

                <?php $no++; } ?>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
       
        </div>
      </div>
    </section>
    <!-- /Main content -->

    <?php
include('koneksi.php');
    $query = mysqli_query($koneksi,"SELECT * FROM perpustakaan ORDER BY id DESC");
    
    ?>
    <?php if(mysqli_num_rows($query)>0){ ?>
    <?php
        $no = 1;
        while($data = mysqli_fetch_array($query)){
    ?>
    <!-- Modal Info -->
    <div class="modal fade" id="info<?=$no?>" tabindex="-1" aria-labelledby="infoLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="infoLabel">Info</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
           
            <table class="table table-borderless">
             
              <tbody>
             
                <tr>
                  <td>Tanggal Pinjam</td>
                  <td>:</td>
                  <td><?php echo $data['tanggal_pinjam'] ?></td>
                </tr>
                <tr>
                  <td>Tanggal Kembali</td>
                  <td>:</td>
                  <td><?php echo $data['tanggal_kembali'] ?></td>
                </tr>
                <tr>
                  <td>Denda</td>
                  <td>:</td>
                  <td><?php echo $data['denda'] ?></td>
                </tr>
       
                
               
              </tbody>
            </table>

          </div>
        </div>
      </div>
    </div>
    <!-- /Modal Info -->
    <?php $no++; } ?>
    <?php } ?>

   

    <!-- Modal Edit -->
    <?php
    include('koneksi.php');
    $query = mysqli_query($koneksi,"SELECT * FROM perpustakaan ORDER BY id DESC");
    
    ?>
    <?php if(mysqli_num_rows($query)>0){ ?>
    <?php
        while($data = mysqli_fetch_array($query)){
    ?>
    <div class="modal fade" id="edit<?=$data['id']?>" tabindex="-1" aria-labelledby="editLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editLabel">Edit Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
           
            <form method="post">
              <input type="hidden" name="id" value="<?=$data['id']?>" >
              <div class="form-group">
                <label for="namaPeminjam">Nama Peminjam</label>
                <input type="text" class="form-control" id="namaPeminjam" name="namaPeminjam" value="<?=$data['nama_peminjam']?>"  placeholder="nama peminjam">
              </div>

              <div class="form-group">
                <label for="namaBuku">Nama Buku</label>
                <input type="text" class="form-control" id="namaBuku" name="namaBuku" value="<?=$data['nama_buku']?>" placeholder="masukan nama">
              </div>
              <div class="form-group">
                <label for="penerbit">Penerbit</label>
                <input type="text" class="form-control" id="penerbit" name="penerbit" value="<?=$data['penerbit']?>" placeholder="penerbit">
              </div>
              
              <div class="form-group">
                <label for="kategori">Kategori Buku</label>
                <select class="form-control" id="kategori" name="kategori">
                <option value="Majalah">Majalah</option>
                  <option value="Novel">Novel</option>
                  <option value="Komik">Komik</option>
                  <option value="Biografi">Biografi</option>
                  <option value="Cergam">Cergam</option>
                  <option value="Dongeng">Dongeng</option>
                </select>
              </div>
              
              <div class="form-group">
                <label for="tanggal_pinjam">Tanggal Pinjam</label>
                <input type="date" class="form-control" id="tanggalPinjam" value="<?=$data['tanggal_pinjam']?>"  name="tanggalPinjam" >
              </div>
              <div class="form-group">
                <label for="tanggalKembali">Tanggal kembali</label>
                <input type="date" class="form-control" id="tanggalKembali" value="<?=$data['tanggal_kembali']?>" name="tanggalKembali" >
              </div>

              <button type="submit" name="submit_edit" class="btn btn-primary">Edit</button>
              <button type="reset" class="btn btn-danger" data-dismiss="modal">Hapus</button>
            </form>


          </div>
        </div>
      </div>
    </div>

    <!-- /Modal Edit -->
    
    <?php } ?>
    <?php } ?>
    
   

     <!-- Modal Tambah-->
     <div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="tambahLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="tambahLabel">Tambah Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
           
            <form method="post">
              <div class="form-group">
                <label for="namaPeminjam">Nama Peminjam</label>
                <input type="text" class="form-control" id="namaPeminjam" name="namaPeminjam"  placeholder="nama peminjam">
              </div>

              <div class="form-group">
                <label for="namaBuku">Nama Buku</label>
                <input type="text" class="form-control" id="namaBuku" name="namaBuku" placeholder="masukan nama">
              </div>
              <div class="form-group">
                <label for="penerbit">Penerbit</label>
                <input type="text" class="form-control" id="penerbit" name="penerbit" placeholder="penerbit">
              </div>
              
              <div class="form-group">
                <label for="kategori">Kategori Buku</label>
                <select class="form-control" id="kategori" name="kategori">
                  <option value="Majalah">Majalah</option>
                  <option value="Novel">Novel</option>
                  <option value="Komik">Komik</option>
                  <option value="Biografi">Biografi</option>
                  <option value="Cergam">Cergam</option>
                  <option value="Dongeng">Dongeng</option>
                </select>
              </div>
              
              <div class="form-group">
                <label for="tanggalPinjam">Tanggal Pinjam</label>
                <input type="date" class="form-control" id="tanggalPinjam" name="tanggalPinjam" >
              </div>
              <div class="form-group">
                <label for="tanggalKembali">Tanggal kembali</label>
                <input type="date" class="form-control" id="tanggalKembali" name="tanggalKembali" >
              </div>

              <button type="submit" name="submit_buku" class="btn btn-primary">Simpan</button>
              <button type="reset" class="btn btn-danger" data-dismiss="modal">Hapus</button>
            </form>


          </div>
        </div>
      </div>
    </div>

    <!-- /Modal Tambah-->

    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
</body>
</html>
