<?php

$koneksi = mysqli_connect("localhost","root","","tugas_pbo");